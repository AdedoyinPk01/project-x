﻿using Sentry;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P21IntegrationWindowsService.Models
{
    public class ContactSyncSeeder
    {
        public ContactSyncSeeder(EventLog eventLog)
        {
            _eventLog = eventLog;
        }

        private readonly static string p21BaseUrl = ConfigurationManager.AppSettings["URL"];
        private readonly static string svcBaseUrl = ConfigurationManager.AppSettings["svcUrl"];
        private static EventLog _eventLog;

        public static void Seed(ContactSyncContext context)
        {
            _eventLog.WriteEntry("Configuring Integration Settings.", EventLogEntryType.Information);
            var date = DateTime.Now;

            context.IntSystemSettings.Add(new Settings()
            {
                Frequency = 15,
                SvcUrl = svcBaseUrl,
                P21Url = p21BaseUrl,
                Company = "LiveOak",
                LastRun = date,
                NextRun = date.AddMinutes(15)
            });

            context.SaveChanges();
            _eventLog.WriteEntry("Integration Settings Configured successfully.", EventLogEntryType.Information);

        }
    }
}
