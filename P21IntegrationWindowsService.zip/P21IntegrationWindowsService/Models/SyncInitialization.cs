﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Sentry;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P21IntegrationWindowsService.Models
{
    public static class SyncInitialization
    {
        /// <summary>
        /// Starting point for P21 - Prokeep Contact Synchronization
        /// </summary>
        /// <remarks>
        /// Process: Gets next run, last run from Integration System Settings to determine when to Initiate the contact synchronization
        /// </remarks>
        public static async void StartSynchronization(EventLog eventLog) //event EventLog eventLog
        {
            try
            {
                ContactSyncContext context = new ContactSyncContext();
                List<Settings> settings = new List<Settings>();
                try
                {
                    eventLog.WriteEntry("Setting up integration config.", EventLogEntryType.Information);
                    settings = await context.IntSystemSettings.ToListAsync();
                }
                catch (SqliteException e)
                {
                    eventLog.WriteEntry(e.Message, EventLogEntryType.Information);
                    ContactSyncSeeder.Seed(context);
                    settings = await context.IntSystemSettings.ToListAsync();
                }
                catch (Exception e)
                {
                    eventLog.WriteEntry(e.Message, EventLogEntryType.Information);
                }

                if (settings.Count == 0)
                {
                    eventLog.WriteEntry("Integration settings hasn't been configured.", EventLogEntryType.Information);
                    SentrySdk.CaptureMessage("Integration settings hasn't been configured.", SentryLevel.Info);
                    ContactSyncSeeder.Seed(context);
                }
                else
                {
                    string nextRun = settings[0].NextRun.ToString();
                    string lastRun = settings[0].LastRun.ToString();
                    double frequency = double.Parse(settings[0].Frequency.ToString());

                    DateTime next_run = (!string.IsNullOrEmpty(nextRun)) ? DateTime.Parse(nextRun)
                            : DateTime.Parse("1900/01/01");
                    DateTime last_run = (!string.IsNullOrEmpty(lastRun)) ? DateTime.Parse(lastRun)
                        : DateTime.Parse("1900/01/01");

                    if (next_run == DateTime.Parse("1900/01/01") || last_run == DateTime.Parse("1900/01/01"))
                    {
                        eventLog.WriteEntry("Contact Synchrozation started.", EventLogEntryType.Information);
                        await InitiateContactSync(context, frequency, eventLog);
                        eventLog.WriteEntry("Contact Synchrozation ended.", EventLogEntryType.Information);
                    }
                    else if (next_run <= DateTime.UtcNow)
                    {
                        //Subtract last run from current time to determine if notification should be sent
                        double minutes = next_run.Subtract(last_run).TotalMinutes;
                        if (minutes >= frequency)
                        {
                            eventLog.WriteEntry("Contact Synchrozation started.", EventLogEntryType.Information);
                            await InitiateContactSync(context, frequency, eventLog);
                            eventLog.WriteEntry("Contact Synchrozation ended.", EventLogEntryType.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // LOG HERE
                _ = ex.Message;
                SentrySdk.CaptureException(ex);
                throw;
            }
        }

        /// <summary>
        /// Intializes the P21 - Prokeep Contact Synchronization
        /// </summary>
        /// <param name="context"></param>
        /// <param name="frequency"></param>
        /// <remarks>
        /// Processes Contacts for Integration and Sets the Next Run using the frequency provided when ProcessContactSync() is completed
        /// </remarks>
        private static async Task InitiateContactSync(ContactSyncContext context, double frequency, EventLog eventLog)
        {
            int icid = Convert.ToInt32(ConfigurationManager.AppSettings["ICID"]);
            Settings integrationSettings = context.IntSystemSettings.Where(setting => setting.ICID == icid).FirstOrDefault();

            // Send Request and process the contacts
            SyncTrigger syncTrigger = new SyncTrigger(eventLog);
            await syncTrigger.ProcessP21ContactSync(integrationSettings.SvcUrl, integrationSettings.P21Url, integrationSettings.Company.ToLower(), icid);
            await syncTrigger.ProcessProkeepSvcContacts(integrationSettings.SvcUrl, integrationSettings.Company.ToLower());

            // Set next run and last run columns in the settings db
            integrationSettings.LastRun = DateTime.Now;
            integrationSettings.NextRun = integrationSettings.LastRun?.AddMinutes(frequency);
            await context.SaveChangesAsync();
        }
    }
}