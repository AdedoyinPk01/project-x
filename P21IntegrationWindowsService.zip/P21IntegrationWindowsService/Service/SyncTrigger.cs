﻿using Newtonsoft.Json;
using Sentry;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using static P21IntegrationWindowsService.Models.P21ResponseObjects;
using static P21IntegrationWindowsService.Models.ProkeepServiceModel;

namespace P21IntegrationWindowsService.Models
{
    public class SyncTrigger
    {
        private static readonly HttpClient httpClient = new HttpClient();
        private readonly string p21EncodedString = ConfigurationManager.AppSettings["EncodedString"];
        private readonly string p21BaseUrl = ConfigurationManager.AppSettings["URL"];
        private readonly string svcUsername = ConfigurationManager.AppSettings["svcUsername"];
        private readonly string svcPassword = ConfigurationManager.AppSettings["svcPassword"];
        private EventLog _eventLog;
        private readonly ContactSyncContext context = new ContactSyncContext();

        private readonly Dictionary<string, object> postRequestBody = new Dictionary<string, object>();
        List<ContactSync> syncedContacts = new List<ContactSync>();

        public SyncTrigger(EventLog eventLog)
        {
            _eventLog = eventLog;
        }

        /// <summary>
        /// Send new or updated contacts from P21 to Prokeep and Process contacts received from Prokeep and finally populates the ContactSyncDB with new/updated contacts
        /// </summary>
        public async Task ProcessP21ContactSync(string svcUrl, string p21BaseUrl, string companyName, int icid)
        {
            try
            {
                string prokeepSvcUrl = $"{svcUrl}{companyName}/";
                // Get Contacts from P21
                string p21Url = $"{p21BaseUrl}entity/contacts/";
                httpClient.DefaultRequestHeaders.Clear();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", p21EncodedString);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/xml"));

                HttpResponseMessage p21response = await httpClient.GetAsync(p21Url);
                string stringContentXML = await p21response.Content.ReadAsStringAsync();
                ArrayOfContact p21Contacts = new ArrayOfContact();

                if (p21response.IsSuccessStatusCode)
                {
                    XDocument doc = XDocument.Parse(stringContentXML);
                    XmlSerializer xml = new XmlSerializer(typeof(ArrayOfContact));
                    p21Contacts = (ArrayOfContact)xml.Deserialize(doc.CreateReader());
                }

                // Get contacts from ContactSyncDB
                syncedContacts.Clear();
                syncedContacts = context.ContactSyncDB.ToList();
                _eventLog.WriteEntry($"P21 Contacts count: {p21Contacts.Contact.Length}, ContactSyncDB Count: {syncedContacts.Count}", EventLogEntryType.Information);

                // Compare Contacts from both results
                if (p21Contacts.Contact != null)
                {
                    foreach (P21ResponseObjects.Contact p21Contact in p21Contacts.Contact)
                    {
                        bool contains = false;
                        if (p21Contact.DirectPhone != null || p21Contact.Cellular != null) // Filter out P21 contacts without phonenumber
                        {
                            if (syncedContacts.Count > 0)
                            {
                                contains = syncedContacts.AsEnumerable().Any(row => p21Contact.Id == row.P21_ID || p21Contact.DirectPhone == row.phone_number || p21Contact.Cellular == row.phone_number);
                            }

                            if (!contains) // New P21 Contact
                            {
                                Debug.WriteLine($"Processing {p21Contact.Id} post to prokeep.");
                                HttpResponseMessage prokeepSvcResponse = await SendContactToProkeepSvc(p21Contact, httpClient, prokeepSvcUrl, icid);

                                if (prokeepSvcResponse.IsSuccessStatusCode)
                                {
                                    try
                                    {
                                        // Send new contacts from Prokeep to ContactSyncDB
                                        Debug.WriteLine($"Posting {p21Contact.Id} to ContactSyncDB.");
                                        await AddContact(prokeepSvcResponse, "prokeepSvcResponse", p21Contact: p21Contact);
                                    }
                                    catch (Exception e)
                                    {
                                        SentrySdk.CaptureException(e);
                                        SentrySdk.CaptureMessage($"An error occured while adding P21 contact: {p21Contact.Id} to the ContactSyncDB.", level: SentryLevel.Error);
                                        _eventLog.WriteEntry($"An error occured while adding P21 contact: {p21Contact.Id} to the ContactSyncDB.", EventLogEntryType.Error);
                                        throw;
                                    }
                                }
                                else
                                {
                                    SentrySdk.CaptureMessage($"P21 contact: {p21Contact.Id} request unsuccessful. Response content: {prokeepSvcResponse.Content}.", level: SentryLevel.Warning);
                                    _eventLog.WriteEntry($"P21 contact: {p21Contact.Id} request unsuccessful. Response content: {prokeepSvcResponse.Content}.", EventLogEntryType.Warning);
                                }
                            }
                            else
                            {
                                string phone = !string.IsNullOrEmpty(p21Contact.DirectPhone) ?
                                    p21Contact.DirectPhone.Trim().Replace("\t", "") : !string.IsNullOrEmpty(p21Contact.Cellular) ?
                                    p21Contact.Cellular.Trim().Replace("\t", "") : null;
                                string emailAddress = !string.IsNullOrEmpty(p21Contact.EmailAddress) ?
                                    p21Contact.EmailAddress.Trim().Replace("\t", "") : null;
                                string firstName = !string.IsNullOrEmpty(p21Contact.FirstName) ? p21Contact.FirstName : null;
                                string lastName = !string.IsNullOrEmpty(p21Contact.LastName) ? p21Contact.LastName : null;

                                try
                                {
                                    // Do a futher Check to see if it's updated or not
                                    ContactSync p21ContactToUpdate = context.ContactSyncDB.Where(contact => contact.P21_ID == p21Contact.Id).FirstOrDefault();
                                    if (p21ContactToUpdate != null && (phone != p21ContactToUpdate.phone_number?.Trim().Replace("\t", "").Replace("-", "").Replace("(", "").Replace(")", "")
                                                          || emailAddress != p21ContactToUpdate.email_address?.Trim().Replace("\t", "")
                                                          || firstName != p21ContactToUpdate.firstname?.Trim().Replace("\t", "")
                                                          || lastName != p21ContactToUpdate.lastname?.Trim().Replace("\t", "")))
                                    {
                                        HttpResponseMessage prokeepSvcResponse = await SendContactToProkeepSvc(p21Contact, httpClient, prokeepSvcUrl, icid, contactId: p21ContactToUpdate.PK_ID);
                                        if (prokeepSvcResponse.IsSuccessStatusCode)  // Update contactsyncdb
                                        {
                                            try
                                            {
                                                await UpdateContact(p21ContactToUpdate.PK_ID, responseMessage: prokeepSvcResponse, responseType: "prokeepSvcResponse", p21Contact: p21Contact);
                                            }
                                            catch (Exception e)
                                            {
                                                SentrySdk.CaptureMessage($"An error occured while updating P21 contact with Prokeep Id: {p21ContactToUpdate.PK_ID} in the ContactSyncDB.", level: SentryLevel.Error);
                                                _eventLog.WriteEntry($"An error occured while updating P21 contact with Prokeep Id: {p21ContactToUpdate.PK_ID} in the ContactSyncDB.", EventLogEntryType.Error);
                                                SentrySdk.CaptureException(e);
                                                _ = e.Message;
                                                throw;
                                            }
                                        }
                                        else
                                        {
                                            SentrySdk.CaptureMessage($"P21 contact: {p21Contact.Id} request unsuccessful. Response content: {prokeepSvcResponse.Content}.", level: SentryLevel.Warning);
                                            _eventLog.WriteEntry($"P21 contact: {p21Contact.Id} request unsuccessful. Response content: {prokeepSvcResponse.Content}.", EventLogEntryType.Warning);
                                        }
                                    }
                                }
                                catch (Exception e)
                                {
                                    SentrySdk.CaptureMessage($"An error occured while updating P21 Contact: {p21Contact.Id}.", level: SentryLevel.Error);
                                    _eventLog.WriteEntry($"An error occured while updating P21 Contact: {p21Contact.Id}.", EventLogEntryType.Error);
                                    SentrySdk.CaptureException(e);
                                    _ = e.Message;
                                    throw;
                                }
                            }
                        }
                    };
                }
            }
            catch (Exception e)
            {
                SentrySdk.CaptureException(e);
                _ = e.Message;
                throw;
            }
        }

        public async Task ProcessProkeepSvcContacts(string url, string companyName)
        {
            try
            {
                string prokeepSvcUrl = $"{url}{companyName}/";
                // Get contacts from ContactSyncDB
                syncedContacts.Clear();
                syncedContacts = context.ContactSyncDB.ToList();

                HttpResponseMessage prokeepSvcResponse = await GetContactsFromProkeepSvc(httpClient, prokeepSvcUrl);
                string stringContent = await prokeepSvcResponse.Content.ReadAsStringAsync();

                if (prokeepSvcResponse.IsSuccessStatusCode)
                {
                    ProkeepServiceModel.Rootobject prokeepContact = JsonConvert.DeserializeObject<ProkeepServiceModel.Rootobject>(stringContent);
                    bool contains = false;

                    foreach (ProkeepServiceModel.Contact pkContact in prokeepContact.contact) // Compare Contacts from ContactSyncDB with prokeeps contact
                    {
                        if (pkContact.phone_number != null) // Filter out P21 contacts without phonenumber
                        {
                            Debug.WriteLine($"Checking: {pkContact.pk_id}");
                            if (syncedContacts.Count > 0)
                            {
                                contains = syncedContacts.AsEnumerable().Any(row => pkContact.phone_number == row.phone_number || pkContact.pk_id == row.PK_ID);
                            }

                            if (!contains) // Prokeep New Contacts
                            {
                                HttpResponseMessage p21ResponseMessage = await SendContactToP21(pkContact, httpClient);

                                if (p21ResponseMessage.IsSuccessStatusCode)
                                {
                                    try
                                    {
                                        // Send new contacts from Prokeep to ContactSyncDB
                                        await AddContact(p21ResponseMessage, "p21", pkContact: pkContact);

                                        // Structure the request body and Send Request
                                        AckObject ackObject = new AckObject { contact = new AckBody[1] };
                                        AckBody ackBody = new AckBody
                                        {
                                            pk_id = pkContact.pk_id,
                                            status = "OK",
                                        };
                                        ackObject.contact[0] = ackBody;

                                        string requestBody = JsonConvert.SerializeObject(ackObject);
                                        string ackUrl = $"{url}Ack/{companyName}/";

                                        HttpResponseMessage responseMessage = await SendRequest(httpClient, requestBody, "json", ackUrl, "Basic", EncodeUsrPwd(svcUsername, svcPassword));

                                        if (responseMessage.IsSuccessStatusCode)
                                        {
                                            Debug.WriteLine($"{pkContact.pk_id} Sync Completed");
                                        }
                                    }
                                    catch (Exception e)
                                    {
                                        SentrySdk.CaptureMessage($"An error occured while adding and acknowledging Prokeep contact: {pkContact.pk_id}.", level: SentryLevel.Error);
                                        _eventLog.WriteEntry($"An error occured while adding and acknowledging Prokeep contact: {pkContact.pk_id}.", EventLogEntryType.Error);
                                        SentrySdk.CaptureException(e);
                                        _ = e.Message;
                                        throw;
                                    }
                                }
                                else
                                {
                                    SentrySdk.CaptureMessage($"Prokeep contact: {pkContact.pk_id} request unsuccessful. Response content: {p21ResponseMessage.Content}.", level: SentryLevel.Warning);
                                    _eventLog.WriteEntry($"Prokeep contact: {pkContact.pk_id} request unsuccessful. Response content: {p21ResponseMessage.Content}.", EventLogEntryType.Warning);
                                }
                            }
                            else // Assumption, there should be a different endpoint or a flag that receives an updated record
                            {
                                string phone = !string.IsNullOrEmpty(pkContact.phone_number) ? pkContact.phone_number.Trim().Replace("\t", "") : null;
                                string emailAddress = !string.IsNullOrEmpty(pkContact.email_address?.ToString()) ? pkContact.email_address.ToString().Trim().Replace("\t", "") : null;
                                string firstName = !string.IsNullOrEmpty(pkContact.first_name?.ToString()) ? pkContact.first_name?.ToString() : null;
                                string lastName = !string.IsNullOrEmpty(pkContact.last_name?.ToString()) ? pkContact.last_name?.ToString() : null;

                                ContactSync contactToUpdate = context.ContactSyncDB.Where(contact => contact.PK_ID == pkContact.pk_id).FirstOrDefault();

                                // Do a futher Check to see if it's updated or not
                                if (phone != contactToUpdate.phone_number?.Trim().Replace("\t", "").Replace("-", "").Replace("(", "").Replace(")", "")
                                          || emailAddress != contactToUpdate.email_address?.Trim().Replace("\t", "").Replace(" ", "")
                                          || firstName != contactToUpdate.firstname?.TrimStart()
                                          || lastName != contactToUpdate.lastname?.TrimStart())
                                {
                                    HttpResponseMessage p21ResponseMessage = await SendContactToP21(pkContact, httpClient, contactToUpdate.PK_ID);
                                    if (p21ResponseMessage.IsSuccessStatusCode)
                                    {
                                        // Send new contacts from Prokeep to ContactSyncDB
                                        try
                                        {
                                            await UpdateContact(ContactToUpdate: contactToUpdate.PK_ID, responseMessage: p21ResponseMessage, responseType: "p21");
                                            // Structure the request body and Send Request
                                            AckObject ackObject = new AckObject { contact = new AckBody[1] };
                                            AckBody ackBody = new AckBody
                                            {
                                                pk_id = pkContact.pk_id,
                                                status = "OK",
                                            };
                                            ackObject.contact[0] = ackBody;

                                            string requestBody = JsonConvert.SerializeObject(ackObject);
                                            string ackUrl = $"{url}Ack/{companyName}";

                                            _ = await SendRequest(httpClient, requestBody, "json", ackUrl, "Basic", EncodeUsrPwd(svcUsername, svcPassword));

                                        }
                                        catch (Exception e)
                                        {
                                            SentrySdk.CaptureMessage($"An error occured while adding and acknowledging Prokeep contact: {pkContact.pk_id}.", level: SentryLevel.Error);
                                            _eventLog.WriteEntry($"An error occured while adding and acknowledging Prokeep contact: {pkContact.pk_id}.", EventLogEntryType.Error);
                                            SentrySdk.CaptureException(e);
                                            _ = e.Message;
                                            throw;
                                        }
                                    }
                                    else
                                    {
                                        SentrySdk.CaptureMessage($"Prokeep contact: {pkContact.pk_id} request unsuccessful. Response content: {p21ResponseMessage.Content}.", level: SentryLevel.Warning);
                                        _eventLog.WriteEntry($"Prokeep contact: {pkContact.pk_id} request unsuccessful. Response content: {p21ResponseMessage.Content}.", EventLogEntryType.Warning);
                                    }
                                }
                            }
                        }

                    };
                }
            }
            catch (Exception e)
            {
                SentrySdk.CaptureException(e);
                _ = e.Message;
                throw;
            }
        }

        // Restructure method depending on the request structure from Prokeep Svc
        /// <summary>
        /// Handles HttpPost Request for both P21 and Prokeep contacts
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestBody"></param>
        /// <param name="mediaType"></param>
        /// <param name="url"></param>
        /// <param name="authType"></param>
        /// <param name="encodedString"></param>
        /// <param name="contactId"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> SendRequest(HttpClient httpClient, object requestBody, string mediaType, string url, string authType = null, string encodedString = null, string contactId = null)
        {
            try
            {
                httpClient.DefaultRequestHeaders.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue($"application/{mediaType}"));

                if (!string.IsNullOrEmpty(authType))
                {
                    httpClient.DefaultRequestHeaders.Add("Authorization", $"{authType} {encodedString}");
                }

                StringContent requestContent = new StringContent(requestBody.ToString(), Encoding.UTF8, $"application/{mediaType}");
                return contactId != null ? await httpClient.PutAsync(url, requestContent) : await httpClient.PostAsync(url, requestContent);
            }
            catch (Exception e)
            {
                SentrySdk.CaptureException(e);
                _ = e.Message;
                throw;
            }
        }

        /// <summary>
        /// Post contact from PROKEEP to P21
        /// </summary>
        /// <param name="contact"></param>
        /// <param name="httpClient"></param>
        /// <param name="contactId"></param>
        /// <returns>P21 Response message</returns>
        public async Task<HttpResponseMessage> SendContactToP21(ProkeepServiceModel.Contact contact, HttpClient httpClient, string contactId = null)
        {
            // Create and Address Id 
            string p21AddressId = CreateP21Address.CreateAddress();

            try
            {
                P21ResponseObjects.Contact p21RequestBody = new P21ResponseObjects.Contact()
                {
                    FirstName = contact.first_name?.ToString(),
                    LastName = contact.last_name?.ToString(),
                    AddressId = Convert.ToUInt32(p21AddressId),
                    Comments = "Prokeep Synced Contact",
                    DirectPhone = contact.phone_number?.ToString(),
                    Cellular = contact.phone_number?.ToString(),
                    EmailAddress = contact.email_address?.ToString(),
                };

                string requestContentXML = XmlSerialize(p21RequestBody);

                string url = $"{p21BaseUrl}entity/contacts/";

                // Post Record to P21
                HttpResponseMessage p21Response = await SendRequest(httpClient, requestBody: requestContentXML, authType: "Bearer", mediaType: "xml", encodedString: p21EncodedString, url: url, contactId: contactId);
                return p21Response;
            }
            catch (Exception e)
            {
                SentrySdk.CaptureMessage($"An error occured while proceesing the request to send Prokeep contact: {contact.pk_id} to P21.");
                SentrySdk.CaptureException(e);
                _ = e.Message;
                throw;
            }
        }

        // <returns>HttpResponseMessage: Received in Json Format</returns>
        // 
        /// <summary>
        /// Post contact from P21 to PROKEEP
        /// </summary>
        /// <param name="contact"></param>
        /// <param name="httpClient"></param>
        /// <param name="contactId"></param>
        /// <returns>Prokeep Service ResponseMessage: Received in Json Format</returns>
        public async Task<HttpResponseMessage> SendContactToProkeepSvc(P21ResponseObjects.Contact contact, HttpClient httpClient, string prokeepSvcUrl, int icid, string contactId = null, string requestType = null)
        {
            try
            {
                ProkeepServiceModel.Rootobject prokeepSvc = new ProkeepServiceModel.Rootobject() { };
                prokeepSvc.customer_name = context.IntSystemSettings.Where(setting => setting.ICID == icid).FirstOrDefault().Company;
                prokeepSvc.contact = new ProkeepServiceModel.Contact[1];
                ProkeepServiceModel.Contact prokeepSvcContact = new ProkeepServiceModel.Contact
                {
                    type = !string.IsNullOrEmpty(contactId) ? "update" : "new",
                    customer_id = null,
                    email_address = contact.EmailAddress.Trim().Replace("\t", ""),
                    external_id = contact.Id,
                    first_name = contact.FirstName.Trim(),
                    last_name = contact.LastName.Trim(),
                    phone_number = contact.DirectPhone.Trim().Replace("\t", "").Replace("-", "").Replace("(", "").Replace(")", ""),
                    pk_id = contactId,
                    fax_number = null,
                };

                prokeepSvc.contact[0] = prokeepSvcContact;

                string jsonRequestBody = JsonConvert.SerializeObject(prokeepSvc);
                string svcEncodedString = EncodeUsrPwd(svcUsername, svcPassword);

                // Post Record 
                HttpResponseMessage response = await SendRequest(httpClient, requestBody: jsonRequestBody, mediaType: "json", url: prokeepSvcUrl, authType: "Basic", encodedString: svcEncodedString);
                return response;
            }
            catch (Exception e)
            {
                SentrySdk.CaptureMessage($"An error occured while processing P21 Contact: {contact.Id} to post Prokeep svc");
                SentrySdk.CaptureException(e);
                _ = e.Message;
                throw;
            }
        }

        /// <summary>
        /// Using Entity Framework to Add new contacts ContactSyncDB
        /// </summary>
        /// <param name="responseMessage"></param>
        /// <param name="pkContact"></param>
        public async Task AddContact(HttpResponseMessage responseMessage, string responseType, ProkeepServiceModel.Contact pkContact = null, P21ResponseObjects.Contact p21Contact = null)
        {
            PSvcResponseObject prokeepResponseObject = new PSvcResponseObject();

            if (responseType == "p21")
            {
                XDocument doc = XDocument.Parse(await responseMessage.Content.ReadAsStringAsync());
                XmlSerializer xml = new XmlSerializer(typeof(P21ResponseObjects.Contact));
                p21Contact = (P21ResponseObjects.Contact)xml.Deserialize(doc.CreateReader());
            }
            else
            {
                var stringContent = await responseMessage.Content.ReadAsStringAsync();
                prokeepResponseObject = JsonConvert.DeserializeObject<PSvcResponseObject>(stringContent);
            }

            try
            {
                // Update the ContactSync DB
                ContactSync sendContact = new ContactSync
                {
                    P21_ID = p21Contact.Id,
                    PK_ID = !string.IsNullOrEmpty(prokeepResponseObject.contact?[0].pk_id) ? prokeepResponseObject.contact?[0].pk_id : !string.IsNullOrEmpty(pkContact.pk_id) ? pkContact.pk_id : null,
                    firstname = !string.IsNullOrEmpty(p21Contact.FirstName) ? p21Contact.FirstName.Trim() : null,
                    lastname = !string.IsNullOrEmpty(p21Contact.LastName) ? p21Contact.LastName.Trim() : null,
                    email_address = !string.IsNullOrEmpty(p21Contact.EmailAddress) ? p21Contact.EmailAddress.Trim().Replace("\t", "") : null,
                    phone_number = !string.IsNullOrEmpty(p21Contact.DirectPhone) ?
                        p21Contact.DirectPhone.Trim().Replace("\t", "").Replace("-", "").Replace("(", "").Replace(")", "") :
                        !string.IsNullOrEmpty(p21Contact.Cellular) ?
                        p21Contact.Cellular.Trim().Replace("\t", "").Replace("-", "").Replace("(", "").Replace(")", "") : null,
                    status = 1,
                    synced_on = DateTime.Now,
                    sync_trigger_by = "P21 Integration",
                    update_trigger_by = !string.IsNullOrEmpty(prokeepResponseObject.contact?[0].updated_by_user_id) ? prokeepResponseObject.contact?[0].updated_by_user_id : null,
                    updated_on = DateTime.Now // Might need to be changed
                };

                _ = context.ContactSyncDB.Add(sendContact);
                _ = await context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                SentrySdk.CaptureMessage($"Failed to add contact to ContactSyncDB.", level: SentryLevel.Info);
                _ = e.Message;
                throw;
            }
        }

        /// <summary>
        /// Using Entity Framework to Update a contact in the ContactSyncDB
        /// </summary>
        /// <param name="ContactToUpdate"></param>
        /// <param name="responseType"></param>
        /// <param name="responseMessage"></param>
        /// <param name="pkContact"></param>
        /// <returns></returns>
        public async Task UpdateContact(string ContactToUpdate, string responseType, HttpResponseMessage responseMessage, P21ResponseObjects.Contact p21Contact = null)
        {
            PSvcResponseObject p21responseObject = new PSvcResponseObject();
            if (responseType == "p21")
            {
                XDocument doc = XDocument.Parse(await responseMessage.Content.ReadAsStringAsync());
                XmlSerializer xml = new XmlSerializer(typeof(P21ResponseObjects.Contact));
                p21Contact = (P21ResponseObjects.Contact)xml.Deserialize(doc.CreateReader());
            }
            else
            {
                string stringContent = await responseMessage.Content.ReadAsStringAsync();
                p21responseObject = JsonConvert.DeserializeObject<PSvcResponseObject>(stringContent);
            }

            try
            {
                ContactSync data = context.ContactSyncDB.Where(contact => contact.PK_ID == ContactToUpdate).FirstOrDefault();
                if (responseType == "prokeepSvcResponse")
                {
                    data.sync_trigger_by = p21responseObject.contact?[0].inserted_by_user_id;
                    data.update_trigger_by = p21responseObject.contact?[0].updated_by_user_id;
                }
                else
                {
                    data.PK_ID = ContactToUpdate;
                }

                data.P21_ID = p21Contact.Id;
                data.firstname = !string.IsNullOrEmpty(p21Contact.FirstName) ? p21Contact.FirstName.Trim() : null;
                data.lastname = !string.IsNullOrEmpty(p21Contact.LastName) ? p21Contact.LastName.Trim() : null;
                data.email_address = !string.IsNullOrEmpty(p21Contact.EmailAddress) ? p21Contact.EmailAddress.Trim().Replace("\t", "") : null;
                data.phone_number = !string.IsNullOrEmpty(p21Contact.DirectPhone) ?
                    p21Contact.DirectPhone.Trim().Replace("\t", "").Replace("-", "").Replace("(", "").Replace(")", "") :
                    !string.IsNullOrEmpty(p21Contact.Cellular) ?
                    p21Contact.Cellular.Trim().Replace("\t", "").Replace("-", "").Replace("(", "").Replace(")", "") : null;
                data.status = 1;
                data.synced_on = DateTime.Now;
                data.updated_on = DateTime.Now;
                _ = await context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                SentrySdk.CaptureMessage($"Failed to add contact to ContactSyncDB.", level: SentryLevel.Info);
                _ = e.Message;
                throw;
            }
        }

        // Will be discarded when Prokeep Svc rest api is called
        public async Task<HttpResponseMessage> GetContactsFromProkeepSvc(HttpClient httpClient, string prokeepContactUrl)
        {
            string prokeepEncodedstring = EncodeUsrPwd(svcUsername, svcPassword);

            // Get Prokeep contacts
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            httpClient.DefaultRequestHeaders.Add("Authorization", $"Basic {prokeepEncodedstring}");
            HttpResponseMessage pkSvcResponse = await httpClient.GetAsync(prokeepContactUrl);

            return pkSvcResponse;
        }

        public string EncodeUsrPwd(string username, string password)
        {
            byte[] byteArray = Encoding.ASCII.GetBytes($"{username}:{password}");
            return Convert.ToBase64String(byteArray);
        }

        public static string XmlSerialize<T>(T entity) where T : class
        {
            // removes version
            XmlWriterSettings settings = new XmlWriterSettings
            {
                OmitXmlDeclaration = true
            };

            XmlSerializer xsSubmit = new XmlSerializer(typeof(T));
            using (StringWriter sw = new StringWriter())
            using (XmlWriter writer = XmlWriter.Create(sw, settings))
            {
                // removes namespace
                XmlSerializerNamespaces xmlns = new XmlSerializerNamespaces();
                xmlns.Add(string.Empty, string.Empty);

                xsSubmit.Serialize(writer, entity, xmlns);
                return sw.ToString(); // Your XML
            }
        }
    }
}
